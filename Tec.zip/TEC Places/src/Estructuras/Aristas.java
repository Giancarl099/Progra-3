/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Estructuras;

/**
 *
 * @author giank
 */
public class Aristas {
    public int Nodo;
    public int peso;
   public Aristas(){
       this.Nodo=0;
   this.peso=0;}
   public Aristas(int N,int P){
       this.Nodo=N;
       this.peso=P;
   }
    
}
