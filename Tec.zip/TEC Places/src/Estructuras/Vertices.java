/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Estructuras;

/**
 *
 * @author giank
 */
import java.util.LinkedList;
public class Vertices<T> {
    public T Vertice;
    public boolean visitado;
    public LinkedList<Aristas> Aristas;
   public Vertices(){
       this.Vertice=null;
       this.visitado=false;
       this.Aristas=new LinkedList<>();
   }
   public Vertices(T V){
       this.Vertice=V;
       this.visitado=false;
       this.Aristas=new LinkedList<>(); 
   }
   public String CadenaV(){
       return "|" + this.Vertice + "|" + "|->";
   }
}
